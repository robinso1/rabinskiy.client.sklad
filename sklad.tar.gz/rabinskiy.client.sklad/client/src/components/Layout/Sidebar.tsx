// Sidebar component
