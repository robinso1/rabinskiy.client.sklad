// WorkerReport component
