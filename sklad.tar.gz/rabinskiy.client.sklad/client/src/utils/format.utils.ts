// Format utilities
