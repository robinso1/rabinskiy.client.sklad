// Auth utilities
