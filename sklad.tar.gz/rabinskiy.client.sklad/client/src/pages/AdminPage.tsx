// AdminPage component
