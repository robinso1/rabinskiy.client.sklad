// Entry point for client
