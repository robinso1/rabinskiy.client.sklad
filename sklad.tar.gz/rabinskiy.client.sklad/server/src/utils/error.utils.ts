// Error utilities
