// Logger utilities
