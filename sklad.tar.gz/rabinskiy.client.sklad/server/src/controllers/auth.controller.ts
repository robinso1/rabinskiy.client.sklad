// Authentication controller
