// Auth configuration
